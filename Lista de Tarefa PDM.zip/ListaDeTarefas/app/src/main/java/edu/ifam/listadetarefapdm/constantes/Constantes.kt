package edu.ifam.listadetarefapdm.constantes

object Constantes {
    const val SEM_PRIORIDADE = 0
    const val PRIORIDADE_BAIXA = 1
    const val PRIORIDADE_MEDIA = 2
    const val PRIORIDADE_ALTA = 3
}