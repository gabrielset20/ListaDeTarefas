package edu.ifam.listadetarefapdm.model

data class Tarefa(
    val tarefa: String? = null,
    val descricao: String? = null,
    val prioridade: Int? = null
)